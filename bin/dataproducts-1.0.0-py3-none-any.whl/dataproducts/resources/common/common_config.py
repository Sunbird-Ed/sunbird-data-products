def init():
    return {
        "kafka_metrics_topic": "telemetry.metrics"
    }
