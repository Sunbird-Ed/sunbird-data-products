def init():
    return [
        {"grade": "KG", "number": 0},
        {"grade": "Class 1", "number": 1},
        {"grade": "Class 2", "number": 2},
        {"grade": "Class 3", "number": 3},
        {"grade": "Class 4", "number": 4},
        {"grade": "Class 5", "number": 5},
        {"grade": "Class 6", "number": 6},
        {"grade": "Class 7", "number": 7},
        {"grade": "Class 8", "number": 8},
        {"grade": "Class 9", "number": 9},
        {"grade": "Class 10", "number": 10},
        {"grade": "Class 11", "number": 11},
        {"grade": "Class 12", "number": 12},
        {"grade": "Other", "number": 13},
        {"grade": "Unknown", "number": 14}
    ]