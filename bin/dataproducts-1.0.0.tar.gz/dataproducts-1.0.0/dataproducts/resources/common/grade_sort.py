from io import StringIO

def init():
    return StringIO("""
        grade,number
        KG,0
        Class 1,1
        Class 2,2
        Class 3,3
        Class 4,4
        Class 5,5
        Class 6,6
        Class 7,7
        Class 8,8
        Class 9,9
        Class 10,10
        Class 11,11
        Class 12,12
        Other,13
        Unknown,14
        """)